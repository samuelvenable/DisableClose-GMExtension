#include "libdisableclose.h"

#if defined(_WIN32)
#include <windows.h>
#elif (defined(__APPLE__) && defined(__MACH__))
#include <AppKit/AppKit.h>
#endif

namespace libdisableclose {

  bool window_get_close_enabled(void *window) {
    if (!window) {
      return false;
    }
    #if defined(_WIN32)
    HMENU hmenu;
    HWND hwnd = (HWND)window;
    if (!IsWindow(hwnd)) {
      return false;
    }
    if (!(hmenu = GetSystemMenu(hwnd, false))) { 
      return false;
    }
    MENUITEMINFO mii = { 
      sizeof(MENUITEMINFO)
    };
    mii.fMask = MIIM_STATE;
    if (GetMenuItemInfo(hmenu, SC_CLOSE, FALSE, &mii)) {
      if (!(mii.fState & MFS_DISABLED)) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
    #elif (defined(__APPLE__) && defined(__MACH__))
    NSWindow *nswnd = (NSWindow *)window;
    return [[nswnd standardWindowButton:NSWindowCloseButton] isEnabled];
    #endif
  }

  bool window_set_close_enabled(void *window, bool enabled) {
    if (!window) {
      return false;
    }
    #if defined(_WIN32)
    HMENU hmenu;
    UINT dw_extra;
    HWND hwnd = (HWND)window;
    if (!IsWindow(hwnd)) {
      return false;
    }
    if (!(hmenu = GetSystemMenu(hwnd, false))) { 
      return false;
    }
    dw_extra = ((enabled) ? MF_ENABLED : (MF_DISABLED | MF_GRAYED));
    return (EnableMenuItem(hmenu, SC_CLOSE, MF_BYCOMMAND | dw_extra) != -1);
    #elif (defined(__APPLE__) && defined(__MACH__))
    NSWindow *nswnd = (NSWindow *)window;
    [[nswnd standardWindowButton:NSWindowCloseButton] setEnabled:((enabled) ? YES : NO)];
    return true;
    #endif
  }

} // namespace libdisableclose
