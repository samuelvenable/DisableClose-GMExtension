#include "libdisableclose.h"

#ifdef _WIN32
#define EXPORTED_FUNCTION extern "C" __declspec(dllexport)
#else /* macOS, Linux, and BSD */
#define EXPORTED_FUNCTION extern "C" __attribute__((visibility("default")))
#endif

EXPORTED_FUNCTION double window_get_close_enabled(void *window) {
  return libdisableclose::window_get_close_enabled(window);
}

EXPORTED_FUNCTION double window_set_close_enabled(void *window, double enabled) {
  return libdisableclose::window_set_close_enabled(window, (int)enabled);
}
